<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src=" http://code.jquery.com/jquery.min.js"></script>
    <script src="client_item.js"></script>
    <link rel="stylesheet" href="style.css">
    <title>page client</title>
</head>
<body>
    <div>
        <h1>Bonjour <span id="mes_information"></span></h1>
        <div id="activite_client">
            <h1>Vos activitées</h1>
            <ul id="activitee"></ul>
        </div>
        <div id="block_activity">
            <h1>Liste d'activité de la boite</h1>
            <ul id="list_activity"></ul>
        </div>
    </div>
</body>
</html>
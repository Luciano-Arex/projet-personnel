<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src=" http://code.jquery.com/jquery.min.js"></script>
    <script src="list_activity.js"></script>
    <title>Liste activity</title>
</head>
<body>
    <div id="block_activity">
        <h1>Liste de activity</h1>
        <ul id="list_activity"></ul>
    </div>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src=" http://code.jquery.com/jquery.min.js"></script>
    <script src="client_item.js"></script>
    <title>page client</title>
</head>
<body>
    
</body>
</html>
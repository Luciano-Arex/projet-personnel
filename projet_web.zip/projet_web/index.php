<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src=" http://code.jquery.com/jquery.min.js"></script>
    <script src="script.js"></script>
    <title>Accueil</title>
</head>
<body>
    <div class="home_content">
        <h1>OPTIONS DU SITE</h1>
        <ul class="fonctionnalite">
            <li><a href="formulaireClient.php">Creer un client</a></li>
            <li><a href="formulaireActivity.php">Creer une activitée</a></li>
            <li><a href="list_client.php">Liste des clients</a></li>
            <li><a href="list_activity.php">Liste des activitéés</a></li>
        </ul>
    </div>
</body>
</html>
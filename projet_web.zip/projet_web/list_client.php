<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src=" http://code.jquery.com/jquery.min.js"></script>
    <script src="list_client.js"></script>
    <title>Liste Client</title>
</head>
<body>
    <div id="block_client">
        <h1>Liste de client</h1>
        <ul id="list_client"></ul>
    </div>
</body>
</html>